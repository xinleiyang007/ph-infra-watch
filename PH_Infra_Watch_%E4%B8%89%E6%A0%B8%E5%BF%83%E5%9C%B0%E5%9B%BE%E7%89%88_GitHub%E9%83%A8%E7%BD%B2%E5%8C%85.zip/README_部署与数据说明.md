# PH Infra Watch · Project Atlas — 三大功能精简静态网站

## 只包含三项核心功能

1. **菲律宾项目地图**：地图显示 projects[] 内有有效坐标的能源及信息化工程；弹窗和详情展示项目规模、业主、投资方、建设方、分包商；无坐标的项目保留在右侧列表中。
2. **工程分类筛选**：新能源（风能、地面光伏、屋顶光伏、充电桩、储能、其他新能源）；信息化（智慧机房/数据中心、弱电/ELV、综合布线/光纤、其他信息化）。
3. **企业角色筛选**：分别按投资方/开发商、建设方/EPC/总包、分包商筛选；多选项目类型取并集，投资方 + 建设方 + 分包商 + 地区多条件取交集。可切换右侧“项目列表 / 企业名录”。

不含新闻页、AI 简报、营销排行等其他模块。网站仍然是纯 HTML/CSS/JS，不需要后端或数据库。

## 文件结构

```
index.html                    ← 正式网站首页（确认后再替换）
v6.html                      ← 测试版页面（先上传，不覆盖旧首页）
data/projects.json           ← 正式项目库（出厂是空数组，绝不混入虚构项目）
examples/projects.demo.json  ← 11 条醒目标记的虚构演示项目，不会被自动读取
examples/project_template.json ← 一个项目的字段模板
README_部署与数据说明.md       ← 本说明
```

网站正常启动时优先加载 `data/projects.json`；如果不存在则尝试旧版 `data/data.json` 里的 `projects[]`（**不会从 news items[] 猜项目**）；两个都不存在则显示空地图和“体验演示”按钮。

演示数据：所有工程、业主和企业名称均是虚构例子，仅用作功能演示。演示地图中的点是城市级参考位置，**不是施工现场坐标**。打开网页点击“体验演示”可以立即测试地图、分类和企业筛选，也可点击“导入项目 JSON”临时导入本地数据；本地导入仅当前浏览器会话有效，不会自动保存到 GitHub。

### JSON 字段（projects[] 每个项目）

| 字段 | 内容 | 必填程度 |
|---|---|---|
| `id` | 不重复的项目 ID | 建议必填 |
| `name` | 项目名称 | 必填 |
| `subtype` | 工程类型代码，见下 | 必填 |
| `province`, `city` | 菲律宾省份 / 城市 | 建议必填 |
| `lat`, `lng` | 经、纬度数值（例：`lat: 14.5, lng: 121.0`） | 上图需要 |
| `location_precision` | `site` / `city` / `municipality` / `province` | 强烈建议填写 |
| `capacity_mw` | 电力容量 MW（仅适用时） | 适用时填写 |
| `project_scale` | 其他规模（MWp、MWh、面积、点位数等，保留原始单位） | 建议填 |
| `investment_php` | 披露投资金额（菲律宾比索 PHP，数值） | 有依据时填 |
| `owner` | 项目所属者 / 业主 | 需要准确角色信息 |
| `investors` | 投资方 / 开发商数组 | 有证据时填写 |
| `contractors` | 建设方、EPC、总包数组 | 有证据时填写 |
| `subcontractors` | 分包商数组 | 有证据时填写 |
| `status` | 工程阶段（可选） | 有证据时填写 |
| `source_url` | 官方项目公告 / 企业公告原始链接 | 强烈建议填写 |

类别代码：`wind`、`solar_ground`、`solar_rooftop`、`ev_charging`、`storage`、`energy_other`、`smart_datacenter`、`elv`、`structured_cabling`、`ict_other`。

注意：业主、投资方、EPC 总包和分包商是不同角色，不能互相替换；没有证据就留空。没有坐标的项目进入列表但不会出现在地图点位；省/城市参考点应标记 `location_precision` 而不是冒充精确工地位置。不同量纲的 MW/MWh/㎡/站点数不参与统一规模排名。

## 免费发布到你自己的 GitHub Pages

根据目前对话，你的仓库为：`xinleiyang007/ph-infra-watch`。

1. 本地解压部署 ZIP。进入仓库的 **Code** 页面；点击 **Add file → Upload files**，**先上传根目录的 `v6.html`**，这样不会覆盖你现有的 `index.html`。测试网址通常是 `https://xinleiyang007.github.io/ph-infra-watch/v6.html`。
2. 添加真实数据文件：在仓库点击 **Add file → Create new file**，把新文件名写成 **`data/projects.json`**（会自动创建 `data` 文件夹），将你的正式 JSON 数据粘贴到编辑区域并提交。或者在 GitHub 网页中打开已有 `data/projects.json`，点击编辑按钮更新。
3. 进入 **Settings → Pages**，选择 `Deploy from a branch`，Branch=`main`，Folder=`/(root)`，点击 Save。如果你已有 Actions 成功部署并且 Pages 设置有效，不必重复配置。
4. 进入 **Actions**，确认最新 `pages build and deployment` 运行成功。然后打开 `https://xinleiyang007.github.io/ph-infra-watch/v6.html`。确认地图和筛选正确后，才上传 `index.html` 覆盖正式首页 `https://xinleiyang007.github.io/ph-infra-watch/`。这些均为预计网址，以 Pages 设置显示为准。
5. 修改 `data/projects.json` 并 Commit 后，GitHub Pages 会发布新版，刷新网站即可看到更新后的项目点位和企业名单。

**公开范围提示：** GitHub Pages 发布的数据文件可以被公众访问，请勿上传联系方式、内部报价、非公开投标文件、账户密码或 API Key。部分 GitHub 计划对 Private 仓库的 Pages 支持有限，须以实际 Settings → Pages 显示为准。

## 数据采集真实性说明

当前只实现浏览器端的地图和结构化筛选，**不等于已自动覆盖全菲律宾所有项目**。要让“所有项目”逐步接近实际覆盖，需要单独的采集及人工核验过程；例如菲律宾 DOE 官方已授予可再生能源项目资料用于能源项目初始目录，并以工程公告、企业公告、政府采购信息补足相关方。网页不会自动推断未知 EPC 或分包商。可参考 DOE Renewable Energy Projects: https://doe.gov.ph/renewable-energy-projects 。

## 地图说明

正常联网时尝试使用开源 Leaflet 1.9.4 和 OpenStreetMap 瓦片，需保留 OSM 版权署名，且应遵守 OSM tile usage policy。若 Leaflet CDN 无法加载，自动显示内嵌 Natural Earth 地理轮廓和可点击项目点位的简化地图。备用地图支持点选详情，不提供真实街道级放大。Natural Earth 轮廓为公共领域地理数据。
